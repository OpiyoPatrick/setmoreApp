package opiyopatrick.setmoreapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.webkit.WebView
import android.webkit.WebViewClient

class secondActivity : AppCompatActivity() {
    private val webView:WebView?= null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)
        title = "SETMORE WEBSITE"

        val webView = findViewById<WebView>(R.id.webview1)
        webView?.webViewClient = WebViewClient()
        webView?.loadUrl("https://www.setmore.com")
        val webSettings = webView.settings
        webSettings.javaScriptEnabled = true

    }

    override fun onBackPressed() {
        if (webView!!.canGoBack()){webView.goBack()}
        else{
        super.onBackPressed()
        }
    }
}